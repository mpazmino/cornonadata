# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'


getCoronaData<-function()
{


  seleccionVariables<-function(datos)
  {
    datos<-select(datos, c(1:6,10:22,34) )
    return(datos)
  }

  aplicacionLimpieza<-function(datos)
  {
    datos<-datos %>%  distinct(id,date,.keep_all=T)

    #NA a 0
    datos$tests[is.na(datos$tests)]<-0
    datos$recovered[is.na(datos$recovered)]<-0
    datos$deaths[is.na(datos$deaths)]<-0

    return(datos)
  }

  aplicacionMissforest<-function(datos)
  {
    datos <-as.data.frame(datos)

    datos.miss <- missForest(datos[,c(3:19)],maxiter=2)

    datos[c(3:19)]<-datos.miss$ximp

    return(datos)

  }


  aplicacionTransformacion<-function(datos)
  {
    fechainicio<-as.Date("2020-02-29")

    fechafin<-Sys.Date()
    datos<-filter(datos,date<fechafin
                  & date>=fechainicio
    )
    #
    datos<- datos%>%
      group_by(id)%>%
      mutate(
        testsDaily=c(0, diff(tests)),
        confirmedDaily=c(0, diff(confirmed)),
        recovereddDaily=c(0, diff(recovered)),
        deathsdDaily=c(0,diff(deaths))
      )

    datos<-mutate(datos,
                  tests100k= (tests/population)*100000,
                  confirmed100k=(confirmed/population)*100000,
                  recovered100k=(recovered/population)*100000,
                  deathsd100k=(deaths/population)*100000)

  }


  cobinadora<-function(datos,transformador)
  {
    return(transformador(datos))
  }


  coronaData<-as.data.frame(covid19(country =c("BRA","ECU","PER","COL","CHL","MEX") ,level = 1,raw = TRUE))

  listaObjetos<-list(coronaData,seleccionVariables,aplicacionLimpieza,
                     aplicacionMissforest,aplicacionTransformacion)

  coronaData<-Reduce(cobinadora,listaObjetos)


  return(coronaData)


}
